package com.cmst.tasksplanner

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class TasksplannerApplication

fun main(args: Array<String>) {
	runApplication<TasksplannerApplication>(*args)
}
